export const STORAGE_KEY = "driveready.family.v1";

export function emptyFamily() {
  return { version: 1, learners: [], drives: [] };
}

export function readFamily(storage) {
  const raw = storage.getItem(STORAGE_KEY);
  if (!raw) return emptyFamily();
  const data = JSON.parse(raw);
  if (data.version !== 1 || !Array.isArray(data.learners) || !Array.isArray(data.drives)) {
    throw new Error("The saved data has an unsupported format.");
  }
  return data;
}

export function summarizeDrives(drives, learnerId) {
  const own = drives.filter((drive) => drive.learnerId === learnerId);
  const totalMinutes = own.reduce((sum, drive) => sum + drive.minutes, 0);
  const nightMinutes = own.reduce((sum, drive) => sum + drive.nightMinutes, 0);
  return { totalMinutes, nightMinutes, dayMinutes: totalMinutes - nightMinutes, count: own.length };
}

export function formatMinutes(minutes) {
  return `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
}

export function validRouteUrl(value) {
  if (!value.trim()) return true;
  try { return new URL(value.trim()).protocol === "https:"; }
  catch { return false; }
}

// Cloud links use a restricted hostname format that can also be checked by Firestore rules.
export function validCloudRouteUrl(value) {
  return value === "" || (value.length <= 2048 && /^https:\/\/([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z]{2,63}([/?#][^\s]*)?$/.test(value) && validRouteUrl(value));
}

export function validCalendarDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value) || value.startsWith("0000")) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export function locationMapUrl(location) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${location.latitude},${location.longitude}`)}`;
}

export function placeMapUrl(place) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(place.trim())}`;
}

export function routeMapUrl(route) {
  const params = new URLSearchParams({ api: "1", origin: route.start, destination: route.end, travelmode: "driving" });
  if (route.stops.length) params.set("waypoints", route.stops.join("|"));
  return `https://www.google.com/maps/dir/?${params}`;
}

// Backups include personal records. Validate before offering to replace local data.
export function parseFamilyBackup(text) {
  const data = JSON.parse(text);
  const invalid = () => { throw new Error("This file is not a supported DriveReady backup."); };
  const string = (value) => typeof value === "string";
  const optionalString = (value) => value === undefined || string(value);
  const stringList = (value) => value === undefined || (Array.isArray(value) && value.every(string));
  if (!data || data.version !== 1 || !Array.isArray(data.learners) || !Array.isArray(data.drives)) invalid();
  const learnerIds = new Set();
  for (const learner of data.learners) {
    if (!learner || !string(learner.id) || !learner.id || !string(learner.name) || !learner.name.trim() || learnerIds.has(learner.id)) invalid();
    learnerIds.add(learner.id);
  }
  const driveIds = new Set();
  for (const drive of data.drives) {
    if (!drive || !string(drive.id) || !drive.id || driveIds.has(drive.id) || !learnerIds.has(drive.learnerId) || !string(drive.date) || !/^\d{4}-\d{2}-\d{2}$/.test(drive.date) || !Number.isInteger(drive.minutes) || drive.minutes < 1 || !Number.isInteger(drive.nightMinutes) || drive.nightMinutes < 0 || drive.nightMinutes > drive.minutes || !string(drive.skills) || !string(drive.notes) || !optionalString(drive.place) || !optionalString(drive.routeUrl) || (drive.routeUrl && !validRouteUrl(drive.routeUrl)) || !stringList(drive.practicedSkills) || !stringList(drive.practicedConditions)) invalid();
    if (drive.route != null && (!string(drive.route.start) || !string(drive.route.end) || !Array.isArray(drive.route.stops) || !drive.route.stops.every(string))) invalid();
    if (drive.location != null && (!Number.isFinite(drive.location.latitude) || Math.abs(drive.location.latitude) > 90 || !Number.isFinite(drive.location.longitude) || Math.abs(drive.location.longitude) > 180 || !Number.isFinite(drive.location.accuracy) || drive.location.accuracy < 0 || !string(drive.location.recordedAt) || !Number.isFinite(Date.parse(drive.location.recordedAt)))) invalid();
    driveIds.add(drive.id);
  }
  return data;
}
